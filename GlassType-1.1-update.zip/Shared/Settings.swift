import Foundation
import KeyboardCore

enum ThemeChoice: String, CaseIterable { case system, light, dark }
enum HapticChoice: String, CaseIterable {
    case off, light, medium, strong
    var title: String {
        switch self {
        case .off: return "Нет"
        case .light: return "Слаб."
        case .medium: return "Сред."
        case .strong: return "Сильно"
        }
    }
}
struct KeyboardSettings {
    // Must match both entitlements after changing the bundle identifier prefix.
    static let group = "group.org.opentype.GlassType"
    var theme: ThemeChoice = .system
    var suggestions = true
    var autoCapitalization = true
    var languages = KeyboardLanguage.allCases
    var haptics: HapticChoice = .off
    var autoCorrection = true
    var compactKeys = true
    var showKeyPreview = true
    var extraSymbols = true
    var symbolHints = true
    var holdDelay: Double = 0.4

    static func load(shared: Bool = true) -> KeyboardSettings {
        let defaults = shared ? (UserDefaults(suiteName: group) ?? .standard) : .standard
        var result = KeyboardSettings()
        result.theme = ThemeChoice(rawValue: defaults.string(forKey: "theme") ?? "") ?? .system
        result.suggestions = defaults.object(forKey: "suggestions") as? Bool ?? true
        result.autoCapitalization = defaults.object(forKey: "capitalization") as? Bool ?? true
        result.autoCorrection = defaults.object(forKey: "autoCorrection") as? Bool ?? true
        result.compactKeys = defaults.object(forKey: "compactKeys") as? Bool ?? true
        result.showKeyPreview = defaults.object(forKey: "showKeyPreview") as? Bool ?? true
        result.haptics = HapticChoice(rawValue: defaults.string(forKey: "haptics") ?? "") ?? .off
        result.extraSymbols = defaults.object(forKey: "extraSymbols") as? Bool ?? true
        result.symbolHints = defaults.object(forKey: "symbolHints") as? Bool ?? true
        result.holdDelay = clampedDelay(defaults.object(forKey: "holdDelay") as? Double ?? 0.4)
        if let values = defaults.stringArray(forKey: "languages") {
            let languages = values.compactMap(KeyboardLanguage.init(rawValue:))
            if !languages.isEmpty { result.languages = languages }
        }
        return result
    }
    func save() {
        let defaults = UserDefaults(suiteName: Self.group) ?? .standard
        defaults.set(theme.rawValue, forKey: "theme")
        defaults.set(suggestions, forKey: "suggestions")
        defaults.set(autoCapitalization, forKey: "capitalization")
        defaults.set(languages.map(\.rawValue), forKey: "languages")
        defaults.set(autoCorrection, forKey: "autoCorrection")
        defaults.set(compactKeys, forKey: "compactKeys")
        defaults.set(showKeyPreview, forKey: "showKeyPreview")
        defaults.set(haptics.rawValue, forKey: "haptics")
        defaults.set(extraSymbols, forKey: "extraSymbols")
        defaults.set(symbolHints, forKey: "symbolHints")
        defaults.set(Self.clampedDelay(holdDelay), forKey: "holdDelay")
    }
    private static let overrideKeys = ["keyboard.haptics", "keyboard.extraSymbols", "keyboard.symbolHints", "keyboard.holdDelay", "keyboard.autoCorrection", "keyboard.compactKeys", "keyboard.showKeyPreview"]
    /// Extension-local overrides make these controls usable with SideStore even
    /// when the re-signed app cannot share an App Group with its extension.
    static func loadKeyboard(fullAccess: Bool) -> KeyboardSettings {
        var result = fullAccess ? load() : KeyboardSettings()
        let defaults = UserDefaults.standard
        if let raw = defaults.string(forKey: overrideKeys[0]), let value = HapticChoice(rawValue: raw) { result.haptics = value }
        if let value = defaults.object(forKey: overrideKeys[1]) as? Bool { result.extraSymbols = value }
        if let value = defaults.object(forKey: overrideKeys[2]) as? Bool { result.symbolHints = value }
        if let value = defaults.object(forKey: overrideKeys[3]) as? Double { result.holdDelay = clampedDelay(value) }
        if let value = defaults.object(forKey: overrideKeys[4]) as? Bool { result.autoCorrection = value }
        if let value = defaults.object(forKey: overrideKeys[5]) as? Bool { result.compactKeys = value }
        if let value = defaults.object(forKey: overrideKeys[6]) as? Bool { result.showKeyPreview = value }
        return result
    }
    func saveKeyboardOverrides() {
        let defaults = UserDefaults.standard
        defaults.set(autoCorrection, forKey: Self.overrideKeys[4])
        defaults.set(compactKeys, forKey: Self.overrideKeys[5])
        defaults.set(showKeyPreview, forKey: Self.overrideKeys[6])
        defaults.set(haptics.rawValue, forKey: Self.overrideKeys[0])
        defaults.set(extraSymbols, forKey: Self.overrideKeys[1])
        defaults.set(symbolHints, forKey: Self.overrideKeys[2])
        defaults.set(Self.clampedDelay(holdDelay), forKey: Self.overrideKeys[3])
    }
    static func clearKeyboardOverrides() {
        for key in overrideKeys { UserDefaults.standard.removeObject(forKey: key) }
    }
    private static func clampedDelay(_ value: Double) -> Double {
        value.isFinite ? min(0.8, max(0.25, value)) : 0.4
    }
}
