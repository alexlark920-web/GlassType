import Foundation

/// Keeps the character flag inside the extension, including the first row and
/// the screen edges. The OS does not allow drawing above the keyboard window.
public struct KeyPreviewLayout {
    public let frame: CGRect
    public let stemCenterX: CGFloat
    public let stemWidth: CGFloat

    public static func make(keyFrame: CGRect, availableBounds: CGRect) -> KeyPreviewLayout? {
        let values = [keyFrame.minX, keyFrame.minY, keyFrame.width, keyFrame.height,
                      availableBounds.minX, availableBounds.minY, availableBounds.width, availableBounds.height]
        guard values.allSatisfy({ $0.isFinite }), keyFrame.width > 0, keyFrame.height > 0,
              availableBounds.width >= 44, availableBounds.height >= 56,
              availableBounds.intersects(keyFrame) else { return nil }
        let width = min(62, min(max(52, keyFrame.width + 22), availableBounds.width - 8))
        let anchorY = min(availableBounds.maxY - 2,
                          max(availableBounds.minY + 50, keyFrame.minY + min(18, keyFrame.height * 0.3)))
        let y = max(availableBounds.minY + 2, anchorY - 68)
        let x = min(max(availableBounds.minX + 4, keyFrame.midX - width / 2), availableBounds.maxX - width - 4)
        let frame = CGRect(x: x, y: y, width: width, height: anchorY - y)
        let stemWidth = min(max(16, keyFrame.width - 8), width - 12)
        let center = min(max(stemWidth / 2 + 2, keyFrame.midX - x), width - stemWidth / 2 - 2)
        return KeyPreviewLayout(frame: frame, stemCenterX: center, stemWidth: stemWidth)
    }
}
