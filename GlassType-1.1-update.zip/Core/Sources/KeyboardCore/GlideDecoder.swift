import Foundation
import CoreGraphics

/// Experimental bounded, local word decoder. No network, learning or text storage.
/// Shapes are compared with the current UIKit key-center geometry on release.
public struct GlideDecoder {
    public init() {}

    public func decode(points: [CGPoint], keyCenters: [String: CGPoint],
                       language: KeyboardLanguage, extraWords: [String] = [], limit: Int = 3) -> [String] {
        guard limit > 0, points.count >= 2, points.count <= 4096 else { return [] }
        let centers = keyCenters.filter { $0.key.count == 1 && finite($0.value) }
        guard (5...64).contains(centers.count), let spacing = keySpacing(centers), spacing > 2 else { return [] }
        let count = min(256, points.count)
        var raw: [CGPoint] = []
        for index in 0..<count {
            let point = points[index * (points.count - 1) / (count - 1)]
            guard finite(point) else { return [] }
            if let last = raw.last, distance(last, point) < 0.5 { continue }
            raw.append(point)
        }
        guard let first = raw.first, let last = raw.last, raw.count >= 2 else { return [] }
        let length = pathLength(raw)
        guard length >= spacing * 0.75, length <= spacing * 60 else { return [] }
        let xs = centers.values.map { Double($0.x) }, ys = centers.values.map { Double($0.y) }
        guard let minX = xs.min(), let maxX = xs.max(), let minY = ys.min(), let maxY = ys.max(),
              raw.allSatisfy({ Double($0.x) >= minX - spacing && Double($0.x) <= maxX + spacing &&
                              Double($0.y) >= minY - spacing && Double($0.y) <= maxY + spacing }) else { return [] }
        let observed = resample(raw, count: 24)
        var seen = Set<String>()
        let words = (Array(extraWords.prefix(200)) + Self.words(for: language)).filter {
            (2...24).contains($0.count) && $0.allSatisfy(\.isLetter)
        }
        var ranked: [(word: String, score: Double)] = []
        for (rank, original) in words.prefix(512).enumerated() {
            let word = original.lowercased()
            guard seen.insert(word).inserted else { continue }
            var template: [CGPoint] = []
            var previousKey: String?
            var supported = true
            for character in word {
                let key = folded(String(character), language: language)
                guard let center = centers[key] else { supported = false; break }
                if key != previousKey { template.append(center) }
                previousKey = key
            }
            guard supported, template.count >= 2, let templateFirst = template.first, let templateLast = template.last,
                  distance(first, templateFirst) <= spacing * 0.9,
                  distance(last, templateLast) <= spacing * 0.9 else { continue }
            let templateLength = pathLength(template)
            guard templateLength > 0 else { continue }
            let ratio = length / templateLength
            guard ratio >= 0.55, ratio <= 1.7 else { continue }
            let ideal = resample(template, count: 24)
            let direct = zip(observed, ideal).reduce(0.0) { $0 + distance($1.0, $1.1) / spacing } / 24
            let warped = alignmentCost(observed, ideal, spacing: spacing)
            let endpoints = (distance(first, templateFirst) + distance(last, templateLast)) / spacing
            let shape = warped * 0.65 + direct * 0.35
            let score = shape + abs(log(ratio)) * 0.22 + endpoints * 0.12 + Double(rank) * 0.00003
            if shape <= 0.48, score <= 0.62 { ranked.append((word, score)) }
        }
        ranked.sort { $0.score == $1.score ? $0.word < $1.word : $0.score < $1.score }
        guard let best = ranked.first else { return [] }
        return ranked.filter { $0.score <= best.score + 0.25 }.prefix(min(limit, 3)).map(\.word)
    }

    private func finite(_ point: CGPoint) -> Bool { point.x.isFinite && point.y.isFinite }
    private func folded(_ key: String, language: KeyboardLanguage) -> String {
        if language == .russian && key == "ё" { return "е" }
        if language == .ukrainian && key == "ґ" { return "г" }
        return key
    }
    private func distance(_ a: CGPoint, _ b: CGPoint) -> Double {
        let x = Double(a.x - b.x), y = Double(a.y - b.y)
        return (x * x + y * y).squareRoot()
    }
    private func keySpacing(_ centers: [String: CGPoint]) -> Double? {
        let points = Array(centers.values)
        let distances = points.enumerated().compactMap { index, point -> Double? in
            points.enumerated().filter { $0.offset != index }.map { distance(point, $0.element) }.filter { $0 > 2 }.min()
        }.sorted()
        return distances.isEmpty ? nil : distances[distances.count / 2]
    }
    private func pathLength(_ points: [CGPoint]) -> Double {
        guard points.count > 1 else { return 0 }
        return (1..<points.count).reduce(0) { $0 + distance(points[$1 - 1], points[$1]) }
    }
    private func resample(_ points: [CGPoint], count: Int) -> [CGPoint] {
        let total = pathLength(points)
        guard total > 0, let first = points.first, let last = points.last else { return [] }
        var result = [first]
        var segment = 1
        var consumed = 0.0
        for sample in 1..<(count - 1) {
            let target = total * Double(sample) / Double(count - 1)
            while segment < points.count - 1 && consumed + distance(points[segment - 1], points[segment]) < target {
                consumed += distance(points[segment - 1], points[segment]); segment += 1
            }
            let start = points[segment - 1], end = points[segment]
            let segmentLength = distance(start, end)
            let fraction = segmentLength > 0 ? min(1, max(0, (target - consumed) / segmentLength)) : 0
            result.append(CGPoint(x: Double(start.x) + Double(end.x - start.x) * fraction,
                                  y: Double(start.y) + Double(end.y - start.y) * fraction))
        }
        result.append(last)
        return result
    }
    private func alignmentCost(_ observed: [CGPoint], _ ideal: [CGPoint], spacing: Double) -> Double {
        let size = observed.count
        guard size > 0, ideal.count == size else { return .infinity }
        let side = size + 1
        var costs = Array(repeating: Double.infinity, count: side * side)
        costs[0] = 0
        for i in 1...size {
            for j in max(1, i - 5)...min(size, i + 5) {
                let d = distance(observed[i - 1], ideal[j - 1]) / spacing
                costs[i * side + j] = d * d + min(costs[(i - 1) * side + j - 1], min(costs[(i - 1) * side + j], costs[i * side + j - 1]))
            }
        }
        return (costs[size * side + size] / Double(size * 2)).squareRoot()
    }
}
