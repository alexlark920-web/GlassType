import Foundation
import CoreGraphics
import XCTest
@testable import KeyboardCore

final class GlideDecoderTests: XCTestCase {
    private let decoder = GlideDecoder()
    private func centers(_ language: KeyboardLanguage) -> [String: CGPoint] {
        var result: [String: CGPoint] = [:]
        for (row, keys) in language.rows.enumerated() {
            for (column, key) in keys.enumerated() {
                result[key] = CGPoint(x: CGFloat(column) * 32 + (row == 1 ? 12 : 0), y: CGFloat(row) * 48)
            }
        }
        return result
    }
    private func path(_ word: String, language: KeyboardLanguage) -> [CGPoint] {
        let geometry = centers(language)
        return word.map { geometry[String($0)]! }
    }
    func testDirectEnglishPath() {
        XCTAssertEqual(decoder.decode(points: path("hello", language: .english), keyCenters: centers(.english), language: .english).first, "hello")
    }
    func testDirectRussianPath() {
        XCTAssertEqual(decoder.decode(points: path("привет", language: .russian), keyCenters: centers(.russian), language: .russian).first, "привет")
    }
    func testDirectUkrainianPath() {
        XCTAssertEqual(decoder.decode(points: path("привіт", language: .ukrainian), keyCenters: centers(.ukrainian), language: .ukrainian).first, "привіт")
    }
    func testConsecutiveRepeatedLettersDoNotRequireLoops() {
        let trace = path("leter", language: .english)
        XCTAssertEqual(decoder.decode(points: trace, keyCenters: centers(.english), language: .english).first, "letter")
    }
    func testSmallFingerOffsetIsTolerated() {
        let trace = path("thanks", language: .english).map { CGPoint(x: $0.x + 3, y: $0.y - 2) }
        XCTAssertEqual(decoder.decode(points: trace, keyCenters: centers(.english), language: .english).first, "thanks")
    }
    func testPersonalWordCanExtendVocabulary() {
        let trace = path("qwerty", language: .english)
        XCTAssertEqual(decoder.decode(points: trace, keyCenters: centers(.english), language: .english, extraWords: ["qwerty"]).first, "qwerty")
    }
    func testInsufficientMovementAndInvalidGeometryAreRejected() {
        let geometry = centers(.english)
        XCTAssertTrue(decoder.decode(points: [], keyCenters: geometry, language: .english).isEmpty)
        XCTAssertTrue(decoder.decode(points: [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 1)], keyCenters: geometry, language: .english).isEmpty)
        XCTAssertTrue(decoder.decode(points: path("hello", language: .english), keyCenters: [:], language: .english).isEmpty)
        XCTAssertTrue(decoder.decode(points: [CGPoint(x: CGFloat.nan, y: 0), .zero], keyCenters: geometry, language: .english).isEmpty)
    }
    func testOffKeyboardScribbleAndExcessiveInputAreRejected() {
        let geometry = centers(.english)
        let trace = [CGPoint(x: 0, y: 0), CGPoint(x: 4000, y: 4000), CGPoint(x: 200, y: 50)]
        XCTAssertTrue(decoder.decode(points: trace, keyCenters: geometry, language: .english).isEmpty)
        XCTAssertTrue(decoder.decode(points: Array(repeating: .zero, count: 5000), keyCenters: geometry, language: .english).isEmpty)
    }
    func testResultsAreBoundedAndUnique() {
        let result = decoder.decode(points: path("hello", language: .english), keyCenters: centers(.english), language: .english, extraWords: ["hello", "hello", "Hello"], limit: 100)
        XCTAssertFalse(result.isEmpty)
        XCTAssertLessThanOrEqual(result.count, 3)
        XCTAssertEqual(result.count, Set(result).count)
        XCTAssertTrue(decoder.decode(points: path("hello", language: .english), keyCenters: centers(.english), language: .english, limit: 0).isEmpty)
    }
    func testEveryLanguageHasARealBaselineVocabulary() {
        for language in KeyboardLanguage.allCases {
            XCTAssertGreaterThan(Set(GlideDecoder.words(for: language)).count, 100)
        }
    }
}
