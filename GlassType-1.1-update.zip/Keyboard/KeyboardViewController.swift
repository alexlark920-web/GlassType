import UIKit
import KeyboardCore

/// Visual keycaps are inset inside contiguous touch targets. Shrinking the
/// visible face does not create dead strips between neighboring keys.
private class KeyButton: UIButton {
    private let face = UIView()
    var fillColor: UIColor = .clear { didSet { face.backgroundColor = fillColor } }
    var compact = true { didSet { setNeedsLayout() } }
    var keyRadius: CGFloat = 8 { didSet { face.layer.cornerRadius = keyRadius } }
    override init(frame: CGRect) {
        super.init(frame: frame)
        face.isUserInteractionEnabled = false; face.isAccessibilityElement = false
        face.layer.cornerRadius = 7; face.layer.cornerCurve = .continuous
        insertSubview(face, at: 0)
        backgroundColor = .clear
        isExclusiveTouch = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func layoutSubviews() {
        super.layoutSubviews()
        let inset: CGFloat = compact ? 3 : 2
        // Update bounds/center, so a highlight transform never changes layout.
        face.bounds = CGRect(origin: .zero, size: CGSize(width: max(0, bounds.width - inset * 2), height: max(0, bounds.height - (compact ? 8 : 6))))
        face.center = CGPoint(x: bounds.midX, y: bounds.midY)
        sendSubviewToBack(face)
    }
    override var isHighlighted: Bool {
        didSet {
            let down = isHighlighted
            let changes = {
                self.face.alpha = down ? 0.72 : 1
                self.face.transform = down && !UIAccessibility.isReduceMotionEnabled ? CGAffineTransform(scaleX: 0.94, y: 0.94) : .identity
            }
            if UIAccessibility.isReduceMotionEnabled { changes() }
            else { UIView.animate(withDuration: down ? 0.055 : 0.11, delay: 0, options: [.beginFromCurrentState, .allowUserInteraction], animations: changes) }
        }
    }
}
private final class DeleteKeyButton: KeyButton {
    var deleteAction: (() -> Void)?
    override func accessibilityActivate() -> Bool {
        guard let deleteAction else { return false }
        deleteAction()
        return true
    }
}

/// UIKit adapter uses the device's local dictionary, without learning words.
private final class SystemSpelling {
    private let checker = UITextChecker()
    func check(_ word: String, language: KeyboardLanguage) -> (known: Bool, candidates: [String]) {
        let available = UITextChecker.availableLanguages
        let preferred: String
        switch language {
        case .english: preferred = "en_US"
        case .russian: preferred = "ru_RU"
        case .ukrainian: preferred = "uk_UA"
        }
        guard let code = available.first(where: { $0 == preferred }) ?? available.first(where: {
            $0.replacingOccurrences(of: "_", with: "-").lowercased().hasPrefix(language.rawValue + "-") || $0 == language.rawValue
        }) else { return (false, []) }
        let text = word.lowercased()
        let range = NSRange(location: 0, length: (text as NSString).length)
        let misspelled = checker.rangeOfMisspelledWord(in: text, range: range, startingAt: 0, wrap: false, language: code)
        if misspelled.location == NSNotFound { return (true, []) }
        return (false, Array((checker.guesses(forWordRange: range, in: text, language: code) ?? []).prefix(8)))
    }
}

final class KeyboardViewController: UIInputViewController {
    private var state = InputState()
    private let theme = KeyboardTheme.material
    private var settings = KeyboardSettings()
    private let provider: any SuggestionProvider = LocalSuggestionProvider()
    private let rows = UIStackView()
    private let suggestions = UIStackView()
    private let toolbar = UIStackView()
    private var feedback: UIImpactFeedbackGenerator?
    private var settingsPanel: UIView?
    private var popupStartX: CGFloat = 0
    private var popupInitialIndex = 0
    private let backdrop = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterial))
    private var heightConstraint: NSLayoutConstraint?
    private var deleteTimer: Timer?
    private var deleteDelay: Timer?
    private var popup: UIView?
    private var popupValues: [String] = []
    private var popupLabels: [UILabel] = []
    private var popupIndex = 0
    private var letterButtons: [(UIButton, String)] = []
    private weak var shiftButton: UIButton?
    private var lastWidth: CGFloat = 0
    private var lastLandscape = false
    private var pendingPrefix: String?
    private var suggestionWords: [String] = []
    private var suggestionSignature: String?
    private let correctionEngine = AutocorrectionEngine()
    private lazy var spelling = SystemSpelling()
    private var correctionUndo: CorrectionUndo?
    private var suppressedCorrection: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        view.isOpaque = false
        inputView?.backgroundColor = .clear
        inputView?.isOpaque = false
        backdrop.isOpaque = false
        NotificationCenter.default.addObserver(self, selector: #selector(updateMaterial), name: UIAccessibility.reduceTransparencyStatusDidChangeNotification, object: nil)
        updateMaterial()
        backdrop.translatesAutoresizingMaskIntoConstraints = false
        rows.translatesAutoresizingMaskIntoConstraints = false
        rows.axis = .vertical; rows.spacing = 0
        toolbar.heightAnchor.constraint(equalToConstant: 32).isActive = true
        view.addSubview(backdrop); view.addSubview(rows)
        NSLayoutConstraint.activate([
            backdrop.leadingAnchor.constraint(equalTo: view.leadingAnchor), backdrop.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backdrop.topAnchor.constraint(equalTo: view.topAnchor), backdrop.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            rows.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 4),
            rows.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -4),
            rows.topAnchor.constraint(equalTo: view.topAnchor, constant: 5),
            rows.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -5)
        ])
        let height = view.heightAnchor.constraint(equalToConstant: 280)
        height.priority = .init(999); height.isActive = true; heightConstraint = height
        reloadSettings()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated); reloadSettings(); updateContext()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated); stopDeleting(); dismissPopup(); hideLocalSettings(); feedback = nil; correctionUndo = nil; suppressedCorrection = nil
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        guard view.bounds.width > 0 else { return }
        // A landscape keyboard can occupy a narrow split-screen host; use screen orientation too.
        let landscape = (view.window?.windowScene?.interfaceOrientation.isLandscape ?? false)
        let desired: CGFloat = (landscape ? (settings.compactKeys ? 188 : 202) : (settings.compactKeys ? 254 : 278)) + view.safeAreaInsets.bottom
        if heightConstraint?.constant != desired { heightConstraint?.constant = desired }
        if abs(lastWidth - view.bounds.width) > 1 || landscape != lastLandscape {
            lastWidth = view.bounds.width; lastLandscape = landscape
            stopDeleting(); dismissPopup()
            for (button, _) in letterButtons { button.titleLabel?.font = .systemFont(ofSize: landscape ? (settings.compactKeys ? 18 : 19) : (settings.compactKeys ? 21 : 22)) }
        }
    }
    override func textDidChange(_ textInput: UITextInput?) { invalidateCorrectionUndo(); updateContext() }
    override func selectionDidChange(_ textInput: UITextInput?) { dismissPopup(); invalidateCorrectionUndo(); updateContext() }
    private func reloadSettings() {
        settings = KeyboardSettings.loadKeyboard(fullAccess: hasFullAccess)
        configureFeedback()
        if !settings.languages.contains(state.language) { state.language = settings.languages.first ?? .english }
        switch settings.theme {
        case .system: overrideUserInterfaceStyle = .unspecified
        case .light: overrideUserInterfaceStyle = .light
        case .dark: overrideUserInterfaceStyle = .dark
        }
        rebuild()
    }
    private func clear(_ stack: UIStackView) {
        stack.arrangedSubviews.forEach { stack.removeArrangedSubview($0); $0.removeFromSuperview() }
    }
    private func rebuild() {
        stopDeleting(); dismissPopup(); hideLocalSettings(); clear(rows); clear(toolbar); clear(suggestions); letterButtons.removeAll(); shiftButton = nil
        suggestionSignature = nil; suggestionWords.removeAll(); correctionUndo = nil
        view.setNeedsLayout()
        suggestions.axis = .horizontal; suggestions.distribution = .fillEqually; suggestions.spacing = 6
        toolbar.axis = .horizontal; toolbar.spacing = 6
        toolbar.addArrangedSubview(suggestions)
        let gear = makeButton("⚙", special: true)
        gear.accessibilityLabel = "Настройки клавиатуры"
        gear.widthAnchor.constraint(equalToConstant: 34).isActive = true
        gear.addAction(UIAction { [weak self] _ in self?.showLocalSettings() }, for: .touchUpInside)
        toolbar.addArrangedSubview(gear)
        rows.addArrangedSubview(toolbar)
        let keyRows = state.symbols ? state.symbolPage.rows : state.language.rows
        for (index, keys) in keyRows.enumerated() {
            let row = UIStackView(); row.axis = .horizontal; row.distribution = .fillEqually; row.spacing = 0
            if index == 2 {
                let shift = makeButton(state.symbols ? state.symbolPage.switchTitle : "⇧", special: true)
                shift.accessibilityLabel = state.symbols ? "Другая страница символов" : "Shift — двойное нажатие: Caps Lock"
                shift.addTarget(self, action: #selector(shiftTapped), for: .touchUpInside)
                shiftButton = shift; row.addArrangedSubview(shift)
            }
            for key in keys {
                let button = makeButton(key)
                button.accessibilityLabel = key
                button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
                let alternatives = state.symbols ? state.language.alternatives(for: key) : state.language.holdAlternatives(for: key, symbolsEnabled: settings.extraSymbols)
                configureHold(on: button, alternatives: alternatives)
                letterButtons.append((button, key)); row.addArrangedSubview(button)
            }
            if index == 2 {
                let delete = makeButton("⌫", special: true); delete.accessibilityLabel = "Удалить"
                (delete as? DeleteKeyButton)?.deleteAction = { [weak self] in self?.deleteOnce() }
                delete.addTarget(self, action: #selector(startDeleting), for: .touchDown)
                delete.addTarget(self, action: #selector(stopDeleting), for: [.touchUpInside, .touchUpOutside, .touchCancel, .touchDragExit])
                delete.accessibilityCustomActions = [UIAccessibilityCustomAction(name: "Удалить символ") { [weak self] _ in self?.deleteOnce(); return true }]
                row.addArrangedSubview(delete)
            }
            rows.addArrangedSubview(row)
        }
        let bottom = UIStackView(); bottom.axis = .horizontal; bottom.spacing = 0
        let symbols = makeButton(state.symbols ? "ABC" : "?123", special: true)
        symbols.addAction(UIAction { [weak self] _ in guard let self else { return }; self.state.symbols.toggle(); if self.state.symbols { self.state.symbolPage = .numbers }; self.rebuild() }, for: .touchUpInside)
        bottom.addArrangedSubview(symbols)
        if needsInputModeSwitchKey {
            let globe = makeButton("◎", special: true); globe.accessibilityLabel = "Следующая системная клавиатура"
            globe.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
            bottom.addArrangedSubview(globe)
        }
        let language = makeButton(state.language.rawValue.uppercased(), special: true)
        language.accessibilityLabel = "Сменить язык: \(state.language.title)"
        language.addAction(UIAction { [weak self] _ in guard let self else { return }; self.state.nextLanguage(enabled: self.settings.languages); self.rebuild() }, for: .touchUpInside)
        bottom.addArrangedSubview(language)
        let space = makeButton(state.language.title); space.accessibilityLabel = "Пробел"
        space.titleLabel?.font = .systemFont(ofSize: 14)
        space.addAction(UIAction { [weak self] _ in self?.insert(" ") }, for: .touchUpInside)
        bottom.addArrangedSubview(space)
        let punctuation = makeButton("."); punctuation.addAction(UIAction { [weak self] _ in self?.insert(".") }, for: .touchUpInside)
        configureHold(on: punctuation, alternatives: state.language.alternatives(for: "."))
        bottom.addArrangedSubview(punctuation)
        let enter = makeButton("", special: true)
        enter.setImage(UIImage(systemName: "return", withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .medium)), for: .normal)
        enter.tintColor = theme.foreground
        enter.accessibilityLabel = returnTitle()
        enter.addAction(UIAction { [weak self] _ in self?.insert("\n") }, for: .touchUpInside)
        bottom.addArrangedSubview(enter)
        let unit = symbols.widthAnchor
        for item in bottom.arrangedSubviews where item !== space && item !== symbols {
            item.widthAnchor.constraint(equalTo: unit, multiplier: item === enter ? 1.35 : 0.85).isActive = true
        }
        space.widthAnchor.constraint(equalTo: unit, multiplier: 3.6).isActive = true
        rows.addArrangedSubview(bottom)
        // Four key rows share remaining height; the suggestion strip has fixed height.
        let keyViews = rows.arrangedSubviews.filter { $0 !== toolbar }
        for row in keyViews.dropFirst() { row.heightAnchor.constraint(equalTo: keyViews[0].heightAnchor).isActive = true }
        refreshLabels(); refreshSuggestions()
    }
    private func makeButton(_ title: String, special: Bool = false) -> UIButton {
        let button: KeyButton = title == "⌫" ? DeleteKeyButton(frame: .zero) : KeyButton(frame: .zero)
        button.compact = settings.compactKeys
        button.keyRadius = theme.radius
        button.contentEdgeInsets = UIEdgeInsets(top: 0, left: 3, bottom: 0, right: 3)
        button.setTitle(title, for: .normal); button.setTitleColor(theme.foreground, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: lastLandscape ? (settings.compactKeys ? 18 : 19) : (settings.compactKeys ? 21 : 22))
        button.titleLabel?.adjustsFontSizeToFitWidth = true; button.titleLabel?.minimumScaleFactor = 0.6
        button.fillColor = theme.key
        button.addAction(UIAction { [weak self] _ in self?.performFeedback() }, for: .touchDown)
        return button
    }
    @objc private func updateMaterial() {
        let reduced = UIAccessibility.isReduceTransparencyEnabled
        backdrop.effect = reduced ? nil : UIBlurEffect(style: .systemThinMaterial)
        backdrop.backgroundColor = reduced ? .secondarySystemBackground : .clear
    }
    private func configureFeedback() {
        let style: UIImpactFeedbackGenerator.FeedbackStyle
        switch settings.haptics {
        case .off: feedback = nil; return
        case .light: style = .light
        case .medium: style = .medium
        case .strong: style = .heavy
        }
        feedback = UIImpactFeedbackGenerator(style: style)
        feedback?.prepare()
    }
    private func performFeedback() {
        feedback?.impactOccurred()
        feedback?.prepare()
    }
    private func configureHold(on button: UIButton, alternatives: [String]) {
        guard !alternatives.isEmpty else { return }
        let press = UILongPressGestureRecognizer(target: self, action: #selector(alternatePress(_:)))
        press.minimumPressDuration = settings.holdDelay
        press.delaysTouchesBegan = false; press.delaysTouchesEnded = false
        button.addGestureRecognizer(press)
        button.accessibilityHint = "Удерживайте для: " + alternatives.joined(separator: ", ")
        button.accessibilityCustomActions = alternatives.map { value in
            UIAccessibilityCustomAction(name: value) { [weak self] _ in self?.performFeedback(); self?.insert(value); return true }
        }
        if settings.symbolHints, let hint = alternatives.first {
            let label = UILabel(); label.text = hint
            label.font = .systemFont(ofSize: 9, weight: .medium)
            label.textColor = .secondaryLabel; label.isUserInteractionEnabled = false
            label.isAccessibilityElement = false; label.translatesAutoresizingMaskIntoConstraints = false
            button.addSubview(label)
            NSLayoutConstraint.activate([
                label.topAnchor.constraint(equalTo: button.topAnchor, constant: 6),
                label.trailingAnchor.constraint(equalTo: button.trailingAnchor, constant: -6)
            ])
            button.titleEdgeInsets = UIEdgeInsets(top: 5, left: 0, bottom: 0, right: 0)
        }
    }
    private func hideLocalSettings() {
        settingsPanel?.removeFromSuperview(); settingsPanel = nil; rows.isHidden = false
    }
    private func showLocalSettings() {
        guard settingsPanel == nil else { return }
        stopDeleting(); dismissPopup()
        let panel = UIView(); panel.backgroundColor = .secondarySystemBackground
        panel.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(panel)
        NSLayoutConstraint.activate([
            panel.leadingAnchor.constraint(equalTo: view.leadingAnchor), panel.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            panel.topAnchor.constraint(equalTo: view.topAnchor), panel.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false
        panel.addSubview(scroll)
        NSLayoutConstraint.activate([
            scroll.leadingAnchor.constraint(equalTo: panel.safeAreaLayoutGuide.leadingAnchor), scroll.trailingAnchor.constraint(equalTo: panel.safeAreaLayoutGuide.trailingAnchor),
            scroll.topAnchor.constraint(equalTo: panel.topAnchor), scroll.bottomAnchor.constraint(equalTo: panel.safeAreaLayoutGuide.bottomAnchor)
        ])
        let content = UIStackView(); content.axis = .vertical; content.spacing = 12
        content.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(content)
        NSLayoutConstraint.activate([
            content.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 12),
            content.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -12),
            content.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 8),
            content.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -12),
            content.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -24)
        ])
        func row(_ title: String, _ control: UIView) {
            let label = UILabel(); label.text = title; label.font = .systemFont(ofSize: 14)
            label.numberOfLines = 2
            let line = UIStackView(arrangedSubviews: [label, control]); line.spacing = 8; line.alignment = .center
            content.addArrangedSubview(line)
        }
        let done = UIButton(type: .system); done.setTitle("Готово", for: .normal)
        done.addAction(UIAction { [weak self] _ in self?.rebuild() }, for: .touchUpInside)
        row("Настройки клавиатуры", done)
        let haptics = UISegmentedControl(items: HapticChoice.allCases.map(\.title))
        haptics.selectedSegmentIndex = HapticChoice.allCases.firstIndex(of: settings.haptics) ?? 0
        haptics.accessibilityLabel = "Сила виброотклика"
        haptics.addAction(UIAction { [weak self, weak haptics] _ in
            guard let self, let haptics, haptics.selectedSegmentIndex >= 0 else { return }
            self.settings.haptics = HapticChoice.allCases[haptics.selectedSegmentIndex]
            self.settings.saveKeyboardOverrides(); self.configureFeedback(); self.performFeedback()
        }, for: .valueChanged)
        row("Виброотклик", haptics)
        let symbols = UISwitch(); symbols.isOn = settings.extraSymbols; symbols.accessibilityLabel = "Дополнительные символы удержанием"
        symbols.addAction(UIAction { [weak self, weak symbols] _ in
            guard let self, let symbols else { return }
            self.settings.extraSymbols = symbols.isOn; self.settings.saveKeyboardOverrides()
        }, for: .valueChanged)
        row("Символы удержанием", symbols)
        let hints = UISwitch(); hints.isOn = settings.symbolHints; hints.accessibilityLabel = "Метки символов на клавишах"
        hints.addAction(UIAction { [weak self, weak hints] _ in
            guard let self, let hints else { return }
            self.settings.symbolHints = hints.isOn; self.settings.saveKeyboardOverrides()
        }, for: .valueChanged)
        row("Метки на клавишах", hints)
        let delay = UISegmentedControl(items: ["0,25 с", "0,4 с", "0,6 с"])
        delay.selectedSegmentIndex = settings.holdDelay < 0.325 ? 0 : (settings.holdDelay < 0.5 ? 1 : 2)
        delay.accessibilityLabel = "Задержка долгого нажатия"
        delay.addAction(UIAction { [weak self, weak delay] _ in
            guard let self, let delay, delay.selectedSegmentIndex >= 0 else { return }
            self.settings.holdDelay = [0.25, 0.4, 0.6][delay.selectedSegmentIndex]; self.settings.saveKeyboardOverrides()
        }, for: .valueChanged)
        row("Удержание", delay)
        let correction = UISwitch(); correction.isOn = settings.autoCorrection; correction.accessibilityLabel = "Автозамена"
        correction.addAction(UIAction { [weak self, weak correction] _ in
            guard let self, let correction else { return }
            self.settings.autoCorrection = correction.isOn; self.settings.saveKeyboardOverrides()
        }, for: .valueChanged)
        row("Автозамена", correction)
        let compact = UISwitch(); compact.isOn = settings.compactKeys; compact.accessibilityLabel = "Компактные клавиши"
        compact.addAction(UIAction { [weak self, weak compact] _ in
            guard let self, let compact else { return }
            self.settings.compactKeys = compact.isOn; self.settings.saveKeyboardOverrides()
        }, for: .valueChanged)
        row("Компактные клавиши", compact)
        let note = UILabel(); note.numberOfLines = 0; note.font = .systemFont(ofSize: 12); note.textColor = .secondaryLabel
        note.text = "Нажмите «Готово», чтобы применить оформление и удержание. Автозамена срабатывает при пробеле или знаке; Backspace сразу после замены возвращает исходное слово. Языковые варианты ё, ґ и диакритика остаются доступны без доп. символов. Если нет вибрации, проверьте полный доступ и настройки тактильных сигналов iOS."
        content.addArrangedSubview(note)
        let reset = UIButton(type: .system); reset.setTitle("Сбросить локальные настройки", for: .normal)
        reset.addAction(UIAction { [weak self] _ in
            KeyboardSettings.clearKeyboardOverrides(); self?.reloadSettings()
        }, for: .touchUpInside)
        content.addArrangedSubview(reset)
        rows.isHidden = true; settingsPanel = panel
        UIAccessibility.post(notification: .screenChanged, argument: done)
    }
    private func returnTitle() -> String {
        switch textDocumentProxy.returnKeyType ?? .default {
        case .go: return "Go"
        case .search: return "Поиск"
        case .send: return "Отпр."
        case .done: return "Готово"
        case .next: return "Далее"
        default: return "Ввод"
        }
    }
    private func insert(_ text: String) {
        if [" ", "\n", ".", ",", "!", "?", ":", ";"].contains(text), applyCorrection(delimiter: text) {
            updateContext(); return
        }
        correctionUndo = nil
        if text.contains(where: { $0.isLetter }) { suppressedCorrection = nil }
        textDocumentProxy.insertText(state.inserted(text)); updateContext()
    }
    private func applyCorrection(delimiter: String) -> Bool {
        guard settings.autoCorrection, (textDocumentProxy.selectedText ?? "").isEmpty,
              textDocumentProxy.autocorrectionType != .no, textDocumentProxy.spellCheckingType != .no,
              let context = textDocumentProxy.documentContextBeforeInput,
              let word = AutocorrectionEngine.trailingPlainWord(in: context) else { return false }
        let type = textDocumentProxy.keyboardType ?? .default
        guard ![UIKeyboardType.URL, .emailAddress, .numberPad, .decimalPad, .phonePad, .namePhonePad, .asciiCapableNumberPad].contains(type) else { return false }
        if suppressedCorrection == word { suppressedCorrection = nil; return false }
        let checked = spelling.check(word, language: state.language)
        guard let replacement = correctionEngine.replacement(for: word, language: state.language, candidates: checked.candidates, isKnownWord: checked.known),
              textDocumentProxy.documentContextBeforeInput == context,
              (textDocumentProxy.selectedText ?? "").isEmpty else { return false }
        correctionUndo = nil
        for _ in word { textDocumentProxy.deleteBackward() }
        textDocumentProxy.insertText(replacement + delimiter)
        _ = state.inserted(delimiter)
        if let before = textDocumentProxy.documentContextBeforeInput, before.hasSuffix(replacement + delimiter) {
            correctionUndo = CorrectionUndo(original: word, replacement: replacement, delimiter: delimiter,
                                            before: before, after: textDocumentProxy.documentContextAfterInput,
                                            document: String(describing: textDocumentProxy.documentIdentifier))
        }
        return true
    }
    private func undoMatches(_ undo: CorrectionUndo) -> Bool {
        undo.matches(before: textDocumentProxy.documentContextBeforeInput, after: textDocumentProxy.documentContextAfterInput,
                     document: String(describing: textDocumentProxy.documentIdentifier),
                     hasSelection: !(textDocumentProxy.selectedText ?? "").isEmpty)
    }
    private func invalidateCorrectionUndo() {
        if let undo = correctionUndo, !undoMatches(undo) { correctionUndo = nil }
    }
    @objc private func shiftTapped() {
        if state.symbols { state.symbolPage = state.symbolPage.next; rebuild(); return }
        state.tapShift(at: ProcessInfo.processInfo.systemUptime); refreshLabels()
    }
    private func refreshLabels() {
        for (button, key) in letterButtons {
            let value = state.symbols || state.shift == .off ? key : key.uppercased()
            if button.title(for: .normal) != value { button.setTitle(value, for: .normal); button.accessibilityLabel = value }
        }
        if !state.symbols { shiftButton?.setTitle(state.shift == .locked ? "⇪" : "⇧", for: .normal) }
        (shiftButton as? KeyButton)?.fillColor = theme.key
        shiftButton?.setTitleColor(state.symbols || state.shift == .off ? theme.foreground : theme.accent, for: .normal)
        shiftButton?.accessibilityValue = state.symbols ? (state.symbolPage == .numbers ? "123" : "#*=") : (state.shift == .locked ? "Caps Lock" : (state.shift == .once ? "Включён" : "Выключен"))
    }
    @objc private func startDeleting() {
        stopDeleting(); deleteOnce()
        let delay = Timer(timeInterval: 0.4, repeats: false) { [weak self] _ in
            guard let self else { return }
            let repeatTimer = Timer(timeInterval: 0.075, repeats: true) { [weak self] _ in self?.deleteOnce() }
            self.deleteTimer = repeatTimer
            RunLoop.main.add(repeatTimer, forMode: .common)
        }
        deleteDelay = delay
        RunLoop.main.add(delay, forMode: .common)
    }
    @objc private func stopDeleting() { deleteDelay?.invalidate(); deleteDelay = nil; deleteTimer?.invalidate(); deleteTimer = nil }
    private func deleteOnce() {
        if let undo = correctionUndo, undoMatches(undo) {
            correctionUndo = nil
            for _ in (undo.replacement + undo.delimiter) { textDocumentProxy.deleteBackward() }
            textDocumentProxy.insertText(undo.original)
            suppressedCorrection = undo.original
        } else {
            correctionUndo = nil; suppressedCorrection = nil
            textDocumentProxy.deleteBackward()
        }
        updateContext()
    }
    private func updateContext() {
        let capitalization = textDocumentProxy.autocapitalizationType ?? .sentences
        state.synchronize(context: textDocumentProxy.documentContextBeforeInput, autoCapitalization: settings.autoCapitalization && capitalization != .none)
        refreshLabels(); refreshSuggestions()
    }
    private func refreshSuggestions() {
        let context = textDocumentProxy.documentContextBeforeInput
        let prefix = context.map { LocalSuggestionProvider.trailingWord(in: String($0.suffix(64))) } ?? ""
        let candidates = settings.suggestions && !prefix.isEmpty && prefix.count < 64 ? provider.suggestions(context: context ?? "", language: state.language) : []
        let words = candidates.map { candidate in
            prefix.first?.isUppercase == true ? (prefix.allSatisfy(\.isUppercase) && prefix.count > 1 ? candidate.uppercased() : candidate.capitalized) : candidate
        }
        pendingPrefix = words.isEmpty ? nil : prefix
        suggestionWords = words
        let signature = state.language.rawValue + "|" + prefix + "|" + words.joined(separator: "|")
        guard suggestionSignature != signature else { return }
        suggestionSignature = signature
        if words.isEmpty {
            if let label = suggestions.arrangedSubviews.first as? UILabel {
                label.text = state.language.title
            } else {
                clear(suggestions)
                let label = UILabel(); label.text = state.language.title; label.textAlignment = .center
                label.font = .systemFont(ofSize: 13); label.textColor = .secondaryLabel
                suggestions.addArrangedSubview(label)
            }
            return
        }
        if suggestions.arrangedSubviews.count != words.count || !(suggestions.arrangedSubviews.first is UIButton) {
            clear(suggestions)
            for index in words.indices {
                let button = makeButton(""); button.titleLabel?.font = .systemFont(ofSize: 16)
                button.addAction(UIAction { [weak self] _ in self?.acceptSuggestion(at: index) }, for: .touchUpInside)
                suggestions.addArrangedSubview(button)
            }
        }
        for (view, word) in zip(suggestions.arrangedSubviews, words) { (view as? UIButton)?.setTitle(word, for: .normal) }
    }
    private func acceptSuggestion(at index: Int) {
        guard suggestionWords.indices.contains(index), let prefix = pendingPrefix else { return }
        accept(suggestionWords[index], prefix: prefix)
    }
    private func accept(_ word: String, prefix: String) {
        // Recheck host context: a selection or cursor move invalidates the candidate.
        guard pendingPrefix == prefix, let context = textDocumentProxy.documentContextBeforeInput,
              LocalSuggestionProvider.trailingWord(in: context) == prefix,
              textDocumentProxy.selectedText == nil else { updateContext(); return }
        correctionUndo = nil; suppressedCorrection = nil
        for _ in prefix { textDocumentProxy.deleteBackward() }
        textDocumentProxy.insertText(word + " "); updateContext()
    }
    @objc private func alternatePress(_ gesture: UILongPressGestureRecognizer) {
        guard let button = gesture.view as? UIButton else { return }
        switch gesture.state {
        case .began:
            stopDeleting()
            let base = button.title(for: .normal)?.lowercased() ?? ""
            let alternatives = state.symbols ? state.language.alternatives(for: base) : state.language.holdAlternatives(for: base, symbolsEnabled: settings.extraSymbols)
            let rect = button.convert(button.bounds, to: view)
            let opensLeft = rect.midX > view.bounds.midX
            let choices = alternatives + [base]
            let values = opensLeft ? Array(choices.reversed()) : choices
            guard values.count > 1 else { return }
            popupValues = values; popupIndex = opensLeft ? values.count - 1 : 0
            popupInitialIndex = popupIndex
            let panel = UIView(); panel.backgroundColor = .secondarySystemBackground
            panel.layer.cornerRadius = 12; panel.layer.borderWidth = 1; panel.layer.borderColor = UIColor.separator.cgColor
            let width = min(CGFloat(values.count) * 40, view.bounds.width - 8)
            let origin = rect.midX - (CGFloat(popupIndex) + 0.5) * width / CGFloat(values.count)
            panel.frame = CGRect(x: min(max(4, origin), view.bounds.width - width - 4), y: max(2, rect.minY - 48), width: width, height: 44)
            for (index, value) in values.enumerated() {
                let label = UILabel(frame: CGRect(x: CGFloat(index) * width / CGFloat(values.count), y: 0, width: width / CGFloat(values.count), height: 44))
                label.textAlignment = .center; label.text = state.symbols || state.shift == .off ? value : value.uppercased(); label.font = .systemFont(ofSize: 23)
                panel.addSubview(label); popupLabels.append(label)
            }
            view.addSubview(panel); popup = panel
            popupStartX = gesture.location(in: panel).x
            performFeedback(); highlightPopup()
        case .changed:
            guard let panel = popup else { return }
            let point = gesture.location(in: panel)
            let offset = (point.x - popupStartX) / (panel.bounds.width / CGFloat(popupValues.count))
            let index = min(max(0, popupInitialIndex + Int(offset.rounded())), popupValues.count - 1)
            if index != popupIndex { popupIndex = index; performFeedback(); highlightPopup() }
        case .ended:
            let value = popupValues.indices.contains(popupIndex) ? popupValues[popupIndex] : nil
            dismissPopup(); if let value { insert(value) }
        case .cancelled, .failed: dismissPopup()
        default: break
        }
    }
    private func highlightPopup() {
        for (index, label) in popupLabels.enumerated() { label.backgroundColor = index == popupIndex ? .systemIndigo.withAlphaComponent(0.25) : .clear }
    }
    private func dismissPopup() { popup?.removeFromSuperview(); popup = nil; popupLabels.removeAll(); popupValues.removeAll() }
    deinit { NotificationCenter.default.removeObserver(self); deleteDelay?.invalidate(); deleteTimer?.invalidate() }
}
