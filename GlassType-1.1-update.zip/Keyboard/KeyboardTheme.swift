import UIKit

/// Opaque keycaps stay distinct from the material background in both themes.
/// All keys share one neutral fill; Shift uses monochrome outline/filled glyphs.
struct KeyboardTheme {
    let key: UIColor
    let function: UIColor
    let accent: UIColor
    let foreground: UIColor
    let radius: CGFloat
    private static let keycap = UIColor { traits in
        UIColor(white: traits.userInterfaceStyle == .dark ? 0.29 : 1.0, alpha: 1)
    }
    static let material = KeyboardTheme(key: keycap, function: keycap,
                                        accent: .systemIndigo,
                                        foreground: .label, radius: 8)
}
