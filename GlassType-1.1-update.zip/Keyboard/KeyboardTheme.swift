import UIKit

/// Opaque keycaps stay distinct from the material background in both themes.
/// UIKit re-resolves these colors when the system or explicit theme changes.
struct KeyboardTheme {
    let key: UIColor
    let function: UIColor
    let accent: UIColor
    let foreground: UIColor
    let radius: CGFloat
    static let material = KeyboardTheme(
        key: UIColor { traits in
            UIColor(white: traits.userInterfaceStyle == .dark ? 0.29 : 1.0, alpha: 1)
        },
        function: UIColor { traits in
            UIColor(white: traits.userInterfaceStyle == .dark ? 0.34 : 0.80, alpha: 1)
        },
        accent: .systemIndigo,
        foreground: .label,
        radius: 8
    )
}
